#!/usr/bin/env python3
"""
██████╗  █████╗ ████████╗ █████╗ ███████╗██╗  ██╗██╗███████╗████████╗
██╔══██╗██╔══██╗╚══██╔══╝██╔══██╗██╔════╝██║  ██║██║██╔════╝╚══██╔══╝
██║  ██║███████║   ██║   ███████║███████╗███████║██║█████╗     ██║
██║  ██║██╔══██║   ██║   ██╔══██║╚════██║██╔══██║██║██╔══╝     ██║
██████╔╝██║  ██║   ██║   ██║  ██║███████║██║  ██║██║██║        ██║
╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝╚═╝        ╚═╝

怠竜 Tearyū · tearyu-datashift · v1.0.0
Universal File Converter — CSV ↔ JSON ↔ XML
Zero dependencies · Pure stdlib · Built for Claude Code

6 conversion paths:
  CSV → JSON  |  CSV → XML
  JSON → CSV  |  JSON → XML
  XML → JSON  |  XML → CSV
"""

import argparse
import csv
import json
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, List, Optional
from xml.dom import minidom

VERSION = "1.0.0"

# ════════════════════════════════════════════════════════════
# UTILITIES
# ════════════════════════════════════════════════════════════

def sanitize_tag(name: str) -> str:
    """Make a string a valid XML tag name."""
    name = str(name).strip()
    name = re.sub(r"[^\w.\-]", "_", name, flags=re.UNICODE)
    if name and (name[0].isdigit() or name[0] == "-"):
        name = "_" + name
    return name or "field"


def err(msg: str) -> None:
    print(f"[ERROR] {msg}", file=sys.stderr)


def warn(msg: str) -> None:
    print(f"[WARN]  {msg}", file=sys.stderr)


def info(msg: str, verbose: bool) -> None:
    if verbose:
        print(f"[INFO]  {msg}")


# ════════════════════════════════════════════════════════════
# FORMAT DETECTION
# ════════════════════════════════════════════════════════════

EXTENSIONS: Dict[str, str] = {
    ".csv": "csv",
    ".json": "json",
    ".jsonl": "json",
    ".xml": "xml",
    ".rss": "xml",
    ".atom": "xml",
    ".svg": "xml",
}


def detect_format(filepath: Path) -> str:
    """
    Detect file format. Priority: file extension → content sniffing.
    Raises ValueError with a helpful message if format cannot be determined.
    """
    ext = filepath.suffix.lower()
    if ext in EXTENSIONS:
        return EXTENSIONS[ext]

    # Content sniffing — read first 512 bytes
    try:
        with open(filepath, "r", encoding="utf-8", errors="replace") as f:
            sample = f.read(512).lstrip()
    except PermissionError:
        raise ValueError(f"Cannot read '{filepath.name}': permission denied.")
    except FileNotFoundError:
        raise ValueError(f"File not found: '{filepath}'")

    if sample.startswith("{") or sample.startswith("["):
        return "json"
    if sample.startswith("<"):
        return "xml"

    # Try CSV heuristic: first two non-empty lines should have the same column count
    lines = [ln for ln in sample.splitlines() if ln.strip()][:5]
    if len(lines) >= 2:
        try:
            counts = [len(next(csv.reader([ln]))) for ln in lines]
            if len(set(counts)) <= 2 and max(counts, default=0) > 1:
                return "csv"
        except Exception:
            pass

    raise ValueError(
        f"Cannot auto-detect format of '{filepath.name}'. "
        "Use --from to specify: csv, json, or xml."
    )


# ════════════════════════════════════════════════════════════
# TYPE INFERENCE
# ════════════════════════════════════════════════════════════

_NULL_VALUES = {"", "null", "none", "n/a", "na", "nil", "-"}
_TRUE_VALUES  = {"true", "yes"}   # "1" excluded — could be an integer
_FALSE_VALUES = {"false", "no"}   # "0" excluded — could be an integer


def infer_scalar(value: str) -> Any:
    """
    Convert a CSV string cell to its most natural Python type.
    Order: null → int → float → bool-word → string.
    Numeric-looking values ("1", "0") are kept as numbers, not booleans.
    """
    stripped = value.strip()
    lower = stripped.lower()

    if lower in _NULL_VALUES:
        return None
    # Integer first — so "1" stays 1, not True
    try:
        return int(stripped)
    except ValueError:
        pass
    # Float
    try:
        return float(stripped)
    except ValueError:
        pass
    # Word-booleans only (true/false/yes/no)
    if lower in _TRUE_VALUES:
        return True
    if lower in _FALSE_VALUES:
        return False
    return stripped


def infer_row(row: Dict[str, str]) -> Dict[str, Any]:
    return {k: infer_scalar(v) for k, v in row.items()}


# ════════════════════════════════════════════════════════════
# FLATTENING / UNFLATTENING
# ════════════════════════════════════════════════════════════

def flatten(obj: Any, prefix: str = "", sep: str = ".") -> Dict[str, Any]:
    """
    Recursively flatten a nested dict/list into a single-level dict.
    Lists are indexed: skills.0, skills.1, …
    """
    out: Dict[str, Any] = {}

    if isinstance(obj, dict):
        for k, v in obj.items():
            new_key = f"{prefix}{sep}{k}" if prefix else str(k)
            if isinstance(v, (dict, list)):
                out.update(flatten(v, new_key, sep))
            else:
                out[new_key] = "" if v is None else v
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            new_key = f"{prefix}{sep}{i}" if prefix else str(i)
            if isinstance(v, (dict, list)):
                out.update(flatten(v, new_key, sep))
            else:
                out[new_key] = "" if v is None else v
    else:
        out[prefix] = "" if obj is None else obj

    return out


# ════════════════════════════════════════════════════════════
# XML ↔ DICT HELPERS
# ════════════════════════════════════════════════════════════

def _strip_ns(tag: str) -> str:
    """Remove XML namespace from a tag: {http://...}foo → foo"""
    return tag.split("}", 1)[-1] if "}" in tag else tag


def xml_elem_to_dict(elem: ET.Element, attr_prefix: str = "@") -> Any:
    """
    Recursively convert an ElementTree Element to a Python dict.
    Rules:
    • Attributes → @attr_name keys
    • Multiple children with the same tag → list
    • Text-only element with no attrs/children → plain string
    • None text is treated as empty string
    """
    result: Dict[str, Any] = {}

    # Attributes
    for k, v in elem.attrib.items():
        result[f"{attr_prefix}{_strip_ns(k)}"] = v

    # Children
    children = list(elem)
    if children:
        child_map: Dict[str, Any] = {}
        for child in children:
            tag = _strip_ns(child.tag)
            data = xml_elem_to_dict(child, attr_prefix)
            if tag in child_map:
                if not isinstance(child_map[tag], list):
                    child_map[tag] = [child_map[tag]]
                child_map[tag].append(data)
            else:
                child_map[tag] = data
        result.update(child_map)

    # Text content
    text = (elem.text or "").strip()
    if text:
        if result:
            result["#text"] = text
        else:
            return text  # leaf node: just return string

    if not result:
        return None

    return result


def _fill_xml_elem(elem: ET.Element, data: Any) -> None:
    """
    Recursively populate an XML Element from a Python dict/list/scalar.
    dict keys starting with '@' become attributes.
    '#text' key becomes the element's text content.
    List values become repeated child elements with the same tag.
    """
    if isinstance(data, dict):
        for k, v in data.items():
            if k.startswith("@"):
                elem.set(k[1:], "" if v is None else str(v))
            elif k == "#text":
                elem.text = str(v)
            elif isinstance(v, list):
                tag = sanitize_tag(k)
                for item in v:
                    child = ET.SubElement(elem, tag)
                    _fill_xml_elem(child, item)
            elif isinstance(v, dict):
                child = ET.SubElement(elem, sanitize_tag(k))
                _fill_xml_elem(child, v)
            else:
                child = ET.SubElement(elem, sanitize_tag(k))
                child.text = "" if v is None else str(v)
    elif isinstance(data, list):
        for item in data:
            child = ET.SubElement(elem, "item")
            _fill_xml_elem(child, item)
    elif data is not None:
        elem.text = str(data)


def pretty_xml(root: ET.Element, indent: int = 2) -> str:
    """Return an indented, well-formed XML string with UTF-8 declaration."""
    raw = ET.tostring(root, encoding="unicode")
    dom = minidom.parseString(f'<?xml version="1.0" encoding="UTF-8"?>{raw}')
    # toprettyxml with encoding returns bytes; decode and strip blank lines
    ugly = dom.toprettyxml(indent=" " * indent, encoding="utf-8").decode("utf-8")
    lines = [ln for ln in ugly.splitlines() if ln.strip()]
    # Normalise declaration to always include encoding="UTF-8"
    if lines and lines[0].startswith("<?xml"):
        lines[0] = '<?xml version="1.0" encoding="UTF-8"?>'
    return "\n".join(lines)


# ════════════════════════════════════════════════════════════
# VALIDATION
# ════════════════════════════════════════════════════════════

def validate_csv(filepath: Path) -> None:
    """Raise ValueError with a descriptive message if CSV is malformed."""
    try:
        with open(filepath, "r", encoding="utf-8", newline="") as f:
            reader = csv.reader(f)
            rows = list(reader)
    except UnicodeDecodeError:
        raise ValueError(
            f"'{filepath.name}' contains non-UTF-8 characters. "
            "Re-save the file as UTF-8 and try again."
        )
    if not rows:
        raise ValueError(f"'{filepath.name}' is empty.")
    if len(rows) == 1:
        raise ValueError(
            f"'{filepath.name}' appears to have only a header row and no data. "
            "Add at least one data row."
        )
    header_len = len(rows[0])
    mismatched = [
        i + 2
        for i, row in enumerate(rows[1:])
        if len(row) != header_len
    ]
    if mismatched:
        warn(
            f"Row(s) {mismatched[:5]}{'…' if len(mismatched) > 5 else ''} "
            f"have a different column count than the header ({header_len} cols). "
            "Missing cells will be empty, extra cells will be ignored."
        )


def validate_json(filepath: Path) -> Any:
    """Parse and return JSON, or raise ValueError with a descriptive message."""
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)
    except UnicodeDecodeError:
        raise ValueError(
            f"'{filepath.name}' contains non-UTF-8 characters. "
            "Re-save the file as UTF-8 and try again."
        )
    except json.JSONDecodeError as exc:
        raise ValueError(
            f"'{filepath.name}' is not valid JSON.\n"
            f"  → {exc.msg} at line {exc.lineno}, column {exc.colno}."
        )


def validate_xml(filepath: Path) -> ET.ElementTree:
    """Parse and return XML ElementTree, or raise ValueError with a descriptive message."""
    try:
        return ET.parse(filepath)
    except UnicodeDecodeError:
        raise ValueError(
            f"'{filepath.name}' contains non-UTF-8 characters. "
            "Check the file's encoding or XML declaration."
        )
    except ET.ParseError as exc:
        raise ValueError(
            f"'{filepath.name}' is not valid XML.\n"
            f"  → {exc}"
        )


# ════════════════════════════════════════════════════════════
# CONVERSION FUNCTIONS
# ════════════════════════════════════════════════════════════

def csv_to_json(src: Path, dst: Path, args) -> Dict[str, Any]:
    """CSV → JSON array of objects. Applies type inference unless --no-inference."""
    validate_csv(src)
    with open(src, "r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        rows: List[Dict] = list(reader)

    if not rows:
        raise ValueError("No data rows found in CSV after parsing.")

    records = [infer_row(r) for r in rows] if args.type_inference else [dict(r) for r in rows]

    with open(dst, "w", encoding="utf-8") as f:
        json.dump(records, f, indent=args.indent, ensure_ascii=False)

    return {"rows": len(records), "fields": list(records[0].keys())}


def csv_to_xml(src: Path, dst: Path, args) -> Dict[str, Any]:
    """CSV → XML. Each row becomes a <record> element under <root>."""
    validate_csv(src)
    with open(src, "r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f)
        rows = list(reader)

    if not rows:
        raise ValueError("No data rows found in CSV after parsing.")

    root_elem = ET.Element(sanitize_tag(args.root))
    for row in rows:
        rec = ET.SubElement(root_elem, sanitize_tag(args.record))
        for key, value in row.items():
            child = ET.SubElement(rec, sanitize_tag(key.strip() or "field"))
            child.text = value if value is not None else ""

    xml_out = pretty_xml(root_elem, args.indent)
    with open(dst, "w", encoding="utf-8") as f:
        f.write(xml_out)

    return {"rows": len(rows), "fields": list(rows[0].keys())}


def json_to_csv(src: Path, dst: Path, args) -> Dict[str, Any]:
    """
    JSON → CSV.
    • Root array of objects → one row per object (nested fields flattened)
    • Root object with an array field → uses that array
    • Single root object → one-row CSV
    • Type: nested objects use dot-notation keys (e.g. address.city)
    """
    data = validate_json(src)

    # Normalize to a list of records
    if isinstance(data, list):
        records = data
    elif isinstance(data, dict):
        # Find the first top-level array value to use as the record set
        array_key = next(
            (k for k, v in data.items() if isinstance(v, list)), None
        )
        if array_key:
            info(f"Using array field '{array_key}' as record source.", args.verbose)
            records = data[array_key]
        else:
            records = [data]
    else:
        raise ValueError(
            "JSON root must be an array of objects or an object containing an array. "
            f"Got: {type(data).__name__}."
        )

    if not records:
        raise ValueError("JSON contains an empty array — no rows to write.")

    # Flatten each record
    flat_records: List[Dict[str, Any]] = []
    for r in records:
        if isinstance(r, (dict, list)):
            flat_records.append(flatten(r, sep=args.flatten_sep))
        else:
            flat_records.append({"value": r})

    # Collect all headers while preserving first-seen order
    seen_keys: Dict[str, None] = {}
    for rec in flat_records:
        for k in rec:
            seen_keys.setdefault(k, None)
    headers = list(seen_keys.keys())

    with open(dst, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=headers, extrasaction="ignore")
        writer.writeheader()
        for rec in flat_records:
            row = {}
            for h in headers:
                v = rec.get(h, "")
                if isinstance(v, bool):
                    row[h] = "true" if v else "false"
                elif isinstance(v, (dict, list)):
                    row[h] = json.dumps(v, ensure_ascii=False)
                elif v is None:
                    row[h] = ""
                else:
                    row[h] = str(v)
            writer.writerow(row)

    return {"rows": len(flat_records), "fields": len(headers), "headers": headers}


def json_to_xml(src: Path, dst: Path, args) -> Dict[str, Any]:
    """
    JSON → XML.
    • Root array → <root><record>…</record>…</root>
    • Root object → element per key, nested recursively
    • Dict keys starting with '@' become XML attributes
    • '#text' key becomes element text content
    """
    data = validate_json(src)

    root_elem = ET.Element(sanitize_tag(args.root))

    if isinstance(data, list):
        for item in data:
            child = ET.SubElement(root_elem, sanitize_tag(args.record))
            _fill_xml_elem(child, item)
        count = len(data)
    else:
        _fill_xml_elem(root_elem, data)
        count = 1

    xml_out = pretty_xml(root_elem, args.indent)
    with open(dst, "w", encoding="utf-8") as f:
        f.write(xml_out)

    return {"items": count}


def xml_to_json(src: Path, dst: Path, args) -> Dict[str, Any]:
    """
    XML → JSON.
    • Uniform children (same tag) → array of objects
    • Mixed children → nested dict keyed by tag name
    • Repeated same-tag children → automatically collected into arrays
    • Attributes → @attr keys
    • Text content of mixed elements → #text key
    """
    tree = validate_xml(src)
    root_elem = tree.getroot()

    children = list(root_elem)

    if not children:
        # Root has no children — just attrs + text
        result = xml_elem_to_dict(root_elem)
    else:
        child_tags = [_strip_ns(c.tag) for c in children]
        if len(set(child_tags)) == 1:
            # All children share a tag → array of records
            result = [xml_elem_to_dict(c) for c in children]
        else:
            # Mixed children → dict keyed by tag
            result = xml_elem_to_dict(root_elem)

    with open(dst, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=args.indent, ensure_ascii=False)

    count = len(result) if isinstance(result, list) else 1
    return {"items": count}


def xml_to_csv(src: Path, dst: Path, args) -> Dict[str, Any]:
    """
    XML → CSV.
    Each direct child of the root element becomes one CSV row.
    Nested elements are flattened with dot-notation keys.
    XML attributes are included with @ prefix.
    """
    tree = validate_xml(src)
    root_elem = tree.getroot()

    children = list(root_elem)
    if not children:
        raise ValueError(
            "XML root element has no children. "
            "DataShift maps each child element to one CSV row — "
            "there must be at least one."
        )

    flat_records: List[Dict[str, Any]] = []
    for child in children:
        d = xml_elem_to_dict(child)
        if isinstance(d, dict):
            flat_records.append(flatten(d, sep=args.flatten_sep))
        elif isinstance(d, str):
            flat_records.append({"value": d})
        elif d is None:
            flat_records.append({})
        else:
            flat_records.append({"value": str(d)})

    if not flat_records:
        raise ValueError("No records could be extracted from XML children.")

    # Collect all headers preserving first-seen order
    seen_keys: Dict[str, None] = {}
    for rec in flat_records:
        for k in rec:
            seen_keys.setdefault(k, None)
    headers = list(seen_keys.keys())

    with open(dst, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=headers, extrasaction="ignore")
        writer.writeheader()
        for rec in flat_records:
            row = {h: ("" if rec.get(h) is None else str(rec.get(h, ""))) for h in headers}
            writer.writerow(row)

    return {"rows": len(flat_records), "fields": len(headers), "headers": headers}


# ════════════════════════════════════════════════════════════
# DISPATCH TABLE
# ════════════════════════════════════════════════════════════

CONVERTERS = {
    ("csv", "json"): csv_to_json,
    ("csv", "xml"):  csv_to_xml,
    ("json", "csv"): json_to_csv,
    ("json", "xml"): json_to_xml,
    ("xml", "json"): xml_to_json,
    ("xml", "csv"):  xml_to_csv,
}

EXT_MAP = {"csv": ".csv", "json": ".json", "xml": ".xml"}


# ════════════════════════════════════════════════════════════
# CLI
# ════════════════════════════════════════════════════════════

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="datashift",
        description=(
            "怠竜 DataShift v{} — CSV ↔ JSON ↔ XML\n"
            "6 conversion paths · Zero dependencies · Pure stdlib"
        ).format(VERSION),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
examples:
  datashift data.csv -t json
  datashift data.csv -t xml --root people --record person
  datashift data.json -t csv
  datashift data.json -t xml
  datashift data.xml -t json
  datashift data.xml -t csv --flatten-sep _
  datashift unknown_file -f xml -t json -o result.json -v

怠竜 · TEARYŪ — The Lazy Dragon
github.com/The-Lazy-Dragon/tearyu-datashift
        """,
    )
    p.add_argument("input", type=Path, help="Input file path")
    p.add_argument(
        "-f", "--from", dest="src_format", choices=["csv", "json", "xml"],
        metavar="FORMAT",
        help="Force source format (default: auto-detect from extension/content)"
    )
    p.add_argument(
        "-t", "--to", dest="dst_format", choices=["csv", "json", "xml"],
        metavar="FORMAT",
        help="Target format — required if output extension is ambiguous"
    )
    p.add_argument(
        "-o", "--output", type=Path,
        help="Output file path (default: same name as input with new extension)"
    )
    p.add_argument(
        "--root", default="root", metavar="TAG",
        help="XML root element name (default: root)"
    )
    p.add_argument(
        "--record", default="record", metavar="TAG",
        help="XML element name per row/item when source is a flat array (default: record)"
    )
    p.add_argument(
        "--indent", type=int, default=2, metavar="N",
        help="Indentation spaces for JSON/XML output (default: 2)"
    )
    p.add_argument(
        "--no-inference", action="store_true",
        help="Disable type inference when converting CSV → JSON (keep all values as strings)"
    )
    p.add_argument(
        "--flatten-sep", default=".", metavar="SEP",
        help="Separator for flattened nested keys in JSON/XML → CSV (default: .)"
    )
    p.add_argument(
        "-v", "--verbose", action="store_true",
        help="Print detailed progress and conversion stats"
    )
    p.add_argument(
        "--version", action="version",
        version=f"tearyu-datashift v{VERSION}"
    )
    return p


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    args.type_inference = not args.no_inference

    # ── Input file must exist ──────────────────────────────
    if not args.input.exists():
        err(f"Input file not found: '{args.input}'")
        return 1
    if not args.input.is_file():
        err(f"'{args.input}' is a directory, not a file.")
        return 1

    # ── Detect source format ───────────────────────────────
    try:
        src_fmt = args.src_format or detect_format(args.input)
    except ValueError as exc:
        err(str(exc))
        return 1

    info(f"Source format: {src_fmt.upper()}", args.verbose)

    # ── Determine target format ────────────────────────────
    if args.dst_format:
        dst_fmt = args.dst_format
    elif args.output:
        try:
            dst_fmt = detect_format(args.output)
        except ValueError:
            err(
                "Cannot infer target format from output filename. "
                "Use --to csv/json/xml to specify it explicitly."
            )
            return 1
    else:
        err(
            "Target format is required. "
            "Use --to csv, --to json, or --to xml."
        )
        return 1

    info(f"Target format: {dst_fmt.upper()}", args.verbose)

    if src_fmt == dst_fmt:
        warn(
            f"Source and target are both {src_fmt.upper()}. "
            "The file will be re-parsed and re-serialized (reformatted)."
        )

    # ── Resolve output path ────────────────────────────────
    if args.output:
        dst_path = args.output
    else:
        new_suffix = EXT_MAP[dst_fmt]
        candidate = args.input.with_suffix(new_suffix)
        if candidate == args.input:
            # Same path → append _converted to stem
            candidate = args.input.with_stem(args.input.stem + "_converted").with_suffix(new_suffix)
        dst_path = candidate

    info(f"Output path: {dst_path}", args.verbose)

    # ── Ensure output directory exists ────────────────────
    dst_path.parent.mkdir(parents=True, exist_ok=True)

    # ── Run conversion ─────────────────────────────────────
    if src_fmt == dst_fmt:
        # Reformat: parse then re-serialize for consistent indentation / encoding
        try:
            if src_fmt == "json":
                data = validate_json(args.input)
                with open(dst_path, "w", encoding="utf-8") as f:
                    json.dump(data, f, indent=args.indent, ensure_ascii=False)
                print(f"[OK] JSON → JSON  '{args.input.name}' → '{dst_path}' (reformatted)")
            elif src_fmt == "xml":
                tree = validate_xml(args.input)
                root_elem = tree.getroot()
                with open(dst_path, "w", encoding="utf-8") as f:
                    f.write(pretty_xml(root_elem, args.indent))
                print(f"[OK] XML → XML  '{args.input.name}' → '{dst_path}' (reformatted)")
            elif src_fmt == "csv":
                validate_csv(args.input)
                with open(args.input, "r", encoding="utf-8", newline="") as f:
                    reader = csv.DictReader(f)
                    rows = list(reader)
                with open(dst_path, "w", encoding="utf-8", newline="") as f:
                    writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()) if rows else [])
                    writer.writeheader()
                    writer.writerows(rows)
                print(f"[OK] CSV → CSV  '{args.input.name}' → '{dst_path}' (reformatted)")
        except ValueError as exc:
            err(str(exc))
            return 1
        return 0

    converter = CONVERTERS.get((src_fmt, dst_fmt))
    if not converter:
        err(f"Unsupported conversion path: {src_fmt} → {dst_fmt}")
        return 1

    try:
        stats = converter(args.input, dst_path, args)
    except ValueError as exc:
        err(str(exc))
        return 1
    except PermissionError:
        err(f"Permission denied writing to '{dst_path}'.")
        return 1
    except Exception as exc:
        err(f"Unexpected error: {exc}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        return 1

    # ── Success output ─────────────────────────────────────
    arrow = f"{src_fmt.upper()} → {dst_fmt.upper()}"
    print(f"[OK] {arrow}  '{args.input.name}' → '{dst_path}'")
    if args.verbose and stats:
        for k, v in stats.items():
            if k != "headers":
                print(f"     {k}: {v}")
            else:
                print(f"     {k}: {v[:8]}{'…' if len(v) > 8 else ''}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
