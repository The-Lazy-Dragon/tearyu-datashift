# Examples — tearyu-datashift

Walkthroughs for all 6 conversion paths using the bundled sample files.
Run from the repo root. All examples assume Python 3.8+.

---

## Sample Files

| File | Content | Structure |
|------|---------|-----------|
| `sample.csv` | 5 people records | Flat: id, name, age, email, city, active |
| `sample.json` | Same 5 records | JSON array of flat objects |
| `sample.xml` | Same 5 records | XML children with element fields |
| `nested.json` | 3 employee records | Nested: role, contact.address, skills array |
| `nested.xml` | 2 catalog items | Attributes, nested tags, repeated `<tag>` children |

---

## Path 1 — CSV → JSON

```bash
python datashift.py examples/sample.csv -t json -o /tmp/out.json -v
```

**Output** (`/tmp/out.json`):
```json
[
  { "id": 1, "name": "Alice Chen", "age": 28, "email": "alice@example.com", "city": "Taipei", "active": true },
  ...
]
```

Type inference converts `"28"` → `28`, `"true"` → `true`. Disable with `--no-inference`.

---

## Path 2 — CSV → XML

```bash
python datashift.py examples/sample.csv -t xml --root people --record person -o /tmp/out.xml
```

**Output** (`/tmp/out.xml`):
```xml
<?xml version="1.0" encoding="UTF-8"?>
<people>
  <person>
    <id>1</id>
    <name>Alice Chen</name>
    <age>28</age>
    ...
  </person>
</people>
```

---

## Path 3 — JSON → CSV (flat)

```bash
python datashift.py examples/sample.json -t csv -o /tmp/out.csv
```

**Output** (`/tmp/out.csv`):
```csv
id,name,age,email,city,active
1,Alice Chen,28,alice@example.com,Taipei,True
```

---

## Path 3b — JSON → CSV (nested, with flattening)

```bash
python datashift.py examples/nested.json -t csv --flatten-sep _ -o /tmp/nested_out.csv -v
```

**Output** (`/tmp/nested_out.csv`):
```csv
id,name,role_title,role_level,role_department,contact_email,contact_address_city,contact_address_country,skills_0,skills_1,skills_2,active,joined
1,Alice Chen,Senior Engineer,L5,Platform,alice@example.com,Taipei,Taiwan,Python,Rust,Go,True,2021-03-15
...
```

Each nested level becomes `parent_child` with `--flatten-sep _`.
Array items become indexed columns: `skills_0`, `skills_1`, `skills_2`.

---

## Path 4 — JSON → XML

```bash
python datashift.py examples/nested.json -t xml --root employees --record employee -o /tmp/out.xml
```

**Output** (`/tmp/out.xml`):
```xml
<?xml version="1.0" encoding="UTF-8"?>
<employees>
  <employee>
    <id>1</id>
    <name>Alice Chen</name>
    <role>
      <title>Senior Engineer</title>
      <level>L5</level>
      <department>Platform</department>
    </role>
    <contact>
      <email>alice@example.com</email>
      <address>
        <city>Taipei</city>
        <country>Taiwan</country>
      </address>
    </contact>
    <skills>Python</skills>
    <skills>Rust</skills>
    <skills>Go</skills>
    ...
  </employee>
</employees>
```

Array values (`"skills": ["Python", "Rust", "Go"]`) become repeated
sibling elements with the parent key as tag name.

---

## Path 5 — XML → JSON

```bash
python datashift.py examples/nested.xml -t json -o /tmp/out.json -v
```

**Output** (`/tmp/out.json`):
```json
[
  {
    "@id": "DS-001",
    "@category": "tool",
    "@status": "stable",
    "name": "tearyu-datashift",
    "description": "Universal file converter. CSV, JSON, XML. Zero dependencies.",
    "author": {
      "@handle": "The-Lazy-Dragon",
      "#text": "怠竜 Tearyū"
    },
    "tags": {
      "tag": ["python", "cli", "data", "converter"]
    },
    "stats": {
      "downloads": "1024",
      "stars": "88",
      "forks": "12"
    },
    "release": {
      "version": "1.0.0",
      "date": "2026-06-02",
      "breaking": "false"
    }
  }
]
```

- XML attributes → `@attr` keys (round-trippable back to XML)
- XML text + attributes mixed → `#text` key for the text content
- Repeated `<tag>` children → JSON array automatically

---

## Path 6 — XML → CSV

```bash
python datashift.py examples/nested.xml -t csv --flatten-sep _ -o /tmp/out.csv -v
```

**Output** (`/tmp/out.csv`):
```csv
@id,@category,@status,name,description,author_@handle,author_#text,tags_tag_0,tags_tag_1,...,stats_downloads,stats_stars,stats_forks,release_version,release_date,release_breaking
DS-001,tool,stable,tearyu-datashift,...,The-Lazy-Dragon,怠竜 Tearyū,python,cli,...,1024,88,12,1.0.0,2026-06-02,false
```

Every attribute, text node, and nested element gets a column.
Array items expand to indexed columns.

---

## Round-Trip Test

Verify lossless round-trips for flat data:

```bash
# CSV → JSON → CSV
python datashift.py examples/sample.csv -t json -o /tmp/step1.json
python datashift.py /tmp/step1.json -t csv -o /tmp/step2.csv --no-inference
diff examples/sample.csv /tmp/step2.csv

# CSV → XML → JSON → CSV
python datashift.py examples/sample.csv -t xml --root people --record person -o /tmp/s1.xml
python datashift.py /tmp/s1.xml -t json -o /tmp/s2.json
python datashift.py /tmp/s2.json -t csv --no-inference -o /tmp/s3.csv
diff examples/sample.csv /tmp/s3.csv
```

Note: type inference introduces Python's `True`/`False` capitalization in CSV
output when converting JSON → CSV. Use `--no-inference` in the original CSV →
JSON step to preserve lowercase `true`/`false` strings if diff matching matters.

---

怠竜 · TEARYŪ — The Lazy Dragon
