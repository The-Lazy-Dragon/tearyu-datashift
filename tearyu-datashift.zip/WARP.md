```
  ██╗    ██╗ █████╗ ██████╗ ██████╗
  ██║    ██║██╔══██╗██╔══██╗██╔══██╗
  ██║ █╗ ██║███████║██████╔╝██████╔╝
  ██║███╗██║██╔══██║██╔══██╗██╔═══╝
  ╚███╔███╔╝██║  ██║██║  ██║██║
   ╚══╝╚══╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝

  怠竜 DataShift · Quick Reference · v1.0.0
```

---

# WARP — DataShift Quick Reference

---

## 6 Conversion Paths

```bash
# CSV → JSON
python datashift.py data.csv -t json

# CSV → XML
python datashift.py data.csv -t xml

# JSON → CSV
python datashift.py data.json -t csv

# JSON → XML
python datashift.py data.json -t xml

# XML → JSON
python datashift.py data.xml -t json

# XML → CSV
python datashift.py data.xml -t csv
```

---

## Power Options

```bash
# Custom output path
python datashift.py data.csv -t xml -o /tmp/output.xml

# Custom XML element names
python datashift.py employees.csv -t xml --root employees --record employee

# No type coercion (keep CSV values as strings)
python datashift.py data.csv -t json --no-inference

# Underscore separator for flattened nested keys
python datashift.py nested.json -t csv --flatten-sep _

# Verbose stats
python datashift.py data.xml -t csv -v

# Force source format (overrides auto-detection)
python datashift.py mystery_file -f xml -t json
```

---

## Format Detection Priority

```
1. File extension (.csv / .json / .xml / .rss / .atom / .jsonl)
2. Content sniff: starts with { or [ → JSON
                  starts with <     → XML
                  comma-consistent  → CSV
3. Error if ambiguous → use --from to specify
```

---

## Nested JSON → CSV (Flattening)

| JSON | CSV header |
|------|-----------|
| `{"address": {"city": "X"}}` | `address.city` |
| `{"address": {"city": "X"}}` with `--flatten-sep _` | `address_city` |
| `{"skills": ["A", "B"]}` | `skills.0`, `skills.1` |
| `[{"a": 1}, {"b": 2}]` | `a`, `b` (merged headers) |

---

## XML → JSON (Attribute Mapping)

| XML | JSON |
|-----|------|
| `<person id="1">` | `{"@id": "1"}` |
| `<name>Alice</name>` | `"name": "Alice"` |
| `<a/><a/><a/>` (same tag) | `"a": [...]` array |
| `<item>text<sub/></item>` | `"#text": "text"` + sub |

---

## JSON → XML (Reverse Mapping)

| JSON | XML |
|------|-----|
| `{"@id": "1"}` | attribute `id="1"` |
| `{"#text": "hi"}` | element text content |
| `[item1, item2]` at root | `<record>` per item |
| `{"tags": ["a", "b"]}` | `<tags>a</tags><tags>b</tags>` |

---

## Exit Codes

| Code | Meaning |
|------|---------|
| `0` | Success |
| `1` | Error (validation, IO, unexpected) |

---

## Type Inference (CSV → JSON)

| CSV cell | JSON value |
|----------|-----------|
| `""`, `null`, `none`, `n/a` | `null` |
| `true`, `yes`, `1` | `true` |
| `false`, `no`, `0` | `false` |
| `"42"` | `42` (int) |
| `"3.14"` | `3.14` (float) |
| everything else | `"string"` |

Disable with `--no-inference`.

---

## Install (Claude Code skill)

```bash
git clone https://github.com/The-Lazy-Dragon/tearyu-datashift \
  ~/.claude/skills/tearyu-datashift
```

---

## Use as Standalone

```bash
# No install needed beyond Python 3.8+
python datashift.py --help
python datashift.py --version
```

---

怠竜 · TEARYŪ — The Lazy Dragon
`github.com/The-Lazy-Dragon/tearyu-datashift`
