---
name: tearyu-datashift
description: >
  怠竜 DataShift — converts files between CSV, JSON, and XML in any direction
  with zero external dependencies. Auto-detects input format from file extension
  or content sniffing. Handles nested JSON objects, JSON arrays, XML attributes,
  XML nested elements, CSV headers, and UTF-8 encoding. Validates files and
  returns descriptive error messages. Use this skill for ANY data format
  conversion task. Trigger on: convert file, csv to json, csv to xml, json to
  csv, json to xml, xml to json, xml to csv, transform data file, change file
  format, reformat data, export as csv, export as json, export as xml, parse
  data file, convert dataset, nested json to csv, flatten json, xml to
  spreadsheet, data migration, convert my data, make this a json file,
  turn this xml into csv.
---

```
  ██████╗  █████╗ ████████╗ █████╗ ███████╗██╗  ██╗██╗███████╗████████╗
  ██╔══██╗██╔══██╗╚══██╔══╝██╔══██╗██╔════╝██║  ██║██║██╔════╝╚══██╔══╝
  ██║  ██║███████║   ██║   ███████║███████╗███████║██║█████╗     ██║
  ██║  ██║██╔══██║   ██║   ██╔══██║╚════██║██╔══██║██║██╔══╝     ██║
  ██████╔╝██║  ██║   ██║   ██║  ██║███████║██║  ██║██║██║        ██║
  ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝╚═╝        ╚═╝

  怠竜 Tearyū · tearyu-datashift · v1.0.0
  Universal File Converter — CSV ↔ JSON ↔ XML
```

---

## What This Skill Does

Converts files between **CSV**, **JSON**, and **XML** across all 6 paths using
the bundled `datashift.py` script. Zero external dependencies — pure Python
stdlib. The script handles format detection, validation, type inference,
nested structure flattening, and UTF-8 encoding transparently.

---

## Step 0: Identify Intent

Determine from context or ask the user:

1. **Source file** — path to the file to convert. If not provided, ask.
2. **Target format** — `csv`, `json`, or `xml`. If not explicit from context, ask.
3. **Output location** — default is same directory as input, same name, new extension.

State both detected source format and target format before running.

---

## Step 1: Locate the Script

The bundled script lives at:
```
~/.claude/skills/tearyu-datashift/datashift.py
```

Check it exists before proceeding:
```bash
ls ~/.claude/skills/tearyu-datashift/datashift.py
```

If missing (e.g., skill was installed without bundled files), fall back to
running the conversion inline using Python stdlib — see **Inline Fallback**
at the bottom of this file.

---

## Step 2: Run the Conversion

Base command:
```bash
python ~/.claude/skills/tearyu-datashift/datashift.py <INPUT> -t <FORMAT> [OPTIONS]
```

### Quick reference — all 6 conversion paths

| Source → Target | Command |
|----------------|---------|
| CSV → JSON | `python datashift.py data.csv -t json` |
| CSV → XML  | `python datashift.py data.csv -t xml` |
| JSON → CSV | `python datashift.py data.json -t csv` |
| JSON → XML | `python datashift.py data.json -t xml` |
| XML → JSON | `python datashift.py data.xml -t json` |
| XML → CSV  | `python datashift.py data.xml -t csv` |

### Available options

| Flag | Default | Effect |
|------|---------|--------|
| `-f`, `--from` | auto | Force source format (`csv`/`json`/`xml`) |
| `-t`, `--to` | required | Target format |
| `-o`, `--output` | auto | Output file path |
| `--root TAG` | `root` | XML root element name |
| `--record TAG` | `record` | XML element per row (for flat arrays) |
| `--indent N` | `2` | Indent spaces in JSON/XML output |
| `--no-inference` | off | Keep CSV cells as strings (no type coercion) |
| `--flatten-sep SEP` | `.` | Separator for flattened nested keys |
| `-v`, `--verbose` | off | Print detailed stats |

### Recommended options by conversion

**CSV → XML with meaningful element names:**
```bash
python datashift.py employees.csv -t xml --root employees --record employee -v
```

**Nested JSON → CSV (use underscore separator for friendlier headers):**
```bash
python datashift.py nested.json -t csv --flatten-sep _ -v
```

**JSON → XML with attributes preserved:**
```bash
python datashift.py data.json -t xml --root catalog --record item -v
```

**XML → JSON (all attributes become @ keys):**
```bash
python datashift.py data.xml -t json -v
```

---

## Step 3: Interpret Output

A successful run prints:
```
[OK] CSV → JSON  'data.csv' → '/path/to/data.json'
     rows: 42
     fields: ['id', 'name', 'email', …]
```

Warnings (`[WARN]`) are non-fatal — conversion still completes. Report them
to the user so they can decide whether the output is acceptable.

Errors (`[ERROR]`) are fatal. See **Error Handling** below.

Always show the user the output file location.

---

## Step 4: Validate Output (Optional but Recommended)

After conversion, do a quick sanity check:

**JSON:** Count top-level items
```bash
python -c "import json; d=json.load(open('output.json')); print(f'{len(d)} records' if isinstance(d,list) else 'object')"
```

**CSV:** Count rows
```bash
python -c "import csv; r=list(csv.DictReader(open('output.csv'))); print(f'{len(r)} rows, {len(r[0]) if r else 0} fields')"
```

**XML:** Count records
```bash
python -c "import xml.etree.ElementTree as ET; root=ET.parse('output.xml').getroot(); print(f'{len(root)} children under <{root.tag}>')"
```

---

## Error Handling

### Common errors and fixes

| Error | Cause | Fix |
|-------|-------|-----|
| `Cannot auto-detect format` | No extension, ambiguous content | Add `--from csv/json/xml` |
| `not valid JSON` | Syntax error in source | Fix the JSON (check commas, quotes, brackets) |
| `not valid XML` | Syntax error in source | Fix the XML (check closing tags, encoding declaration) |
| `only a header row` | CSV has headers but no data | Add at least one data row |
| `No records found` | JSON has no array to iterate | Use `--from json` and verify structure |
| `permission denied` | Output path not writable | Use `-o /tmp/output.ext` or check directory permissions |
| `non-UTF-8 characters` | Wrong encoding | Re-save source as UTF-8 in your editor |

### When the user's data has unusual structure

**JSON with no root array:**
If the JSON is a single flat object, `json_to_csv` wraps it in a one-row CSV.
Nested object → flattened columns using the `--flatten-sep` separator.

**XML with deeply nested elements:**
`xml_to_csv` flattens up to arbitrary depth. Keys follow dot notation:
`person.address.city`, `person.contact.@type`. If columns look messy, try
`--flatten-sep _` for underscore-separated keys.

**CSV with inconsistent column counts:**
The script warns on mismatched row lengths but continues. Missing cells
become empty strings. Extra cells are dropped.

**CSV with mixed encodings / BOM:**
Python's csv module handles UTF-8-BOM automatically. For other encodings
(Latin-1, Windows-1252), pre-convert the file:
```bash
python -c "open('out.csv','w',encoding='utf-8').write(open('in.csv',encoding='latin-1').read())"
```

---

## Data Preservation Rules

| Source structure | How it's preserved |
|-----------------|-------------------|
| CSV headers | Become JSON keys / XML element names (sanitized) |
| CSV type values | Inferred as int/float/bool/null in JSON (disable with `--no-inference`) |
| JSON nested objects | Flattened to `parent.child` keys in CSV |
| JSON arrays (root) | One row per item in CSV |
| JSON arrays (nested) | Joined as repeated XML elements or flattened as indexed keys in CSV |
| JSON `@attr` keys | Become XML attributes |
| JSON `#text` keys | Become XML text content |
| XML attributes | Become `@attr` keys in JSON / `@attr` columns in CSV |
| XML nested elements | Recursively converted to nested JSON / dot-notation CSV |
| XML repeated same-tag children | Become JSON arrays |
| UTF-8 characters | Preserved throughout (ensure_ascii=False) |

---

## Examples Directory

Examples live at `~/.claude/skills/tearyu-datashift/examples/`.
See `examples/README.md` for a walkthrough of all 6 conversion paths using
the bundled sample files.

---

## Inline Fallback

If `datashift.py` is not found, copy it from this skill's GitHub repo or
perform the conversion inline. Here is a minimal inline approach for the
most common paths using only Python stdlib:

**Quick CSV → JSON (inline, no script):**
```python
import csv, json, sys
with open(sys.argv[1], encoding='utf-8') as f:
    data = list(csv.DictReader(f))
print(json.dumps(data, indent=2, ensure_ascii=False))
```

**Quick JSON → CSV (inline, no script, flat objects only):**
```python
import csv, json, sys
data = json.load(open(sys.argv[1]))
if isinstance(data, dict): data = [data]
headers = list(data[0].keys())
w = csv.DictWriter(sys.stdout, fieldnames=headers)
w.writeheader(); w.writerows(data)
```

For all other paths or complex structures, the full `datashift.py` script
is required.

---

## Tuning Notes

- **Output looks truncated:** Add `-v` for full stats. The script always
  writes the full file — check the actual output file, not stdout.
- **XML tags have underscores where headers had spaces:** XML tag names
  can't contain spaces; this is expected sanitization behavior.
- **JSON → CSV drops some keys:** If a nested record has a key that the
  first record doesn't, it may be absent from headers. Run with `-v` to
  see all headers collected.
- **XML → JSON produces `@`-prefixed keys:** Those are XML attributes,
  which the JSON convention (`@attr`) makes round-trippable back to XML.

---

怠竜 · TEARYŪ — The Lazy Dragon
`github.com/The-Lazy-Dragon/tearyu-datashift`
