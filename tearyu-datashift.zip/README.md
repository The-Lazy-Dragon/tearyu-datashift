<div align="center">

```
██████╗  █████╗ ████████╗ █████╗ ███████╗██╗  ██╗██╗███████╗████████╗
██╔══██╗██╔══██╗╚══██╔══╝██╔══██╗██╔════╝██║  ██║██║██╔════╝╚══██╔══╝
██║  ██║███████║   ██║   ███████║███████╗███████║██║█████╗     ██║
██║  ██║██╔══██║   ██║   ██╔══██║╚════██║██╔══██║██║██╔══╝     ██║
██████╔╝██║  ██║   ██║   ██║  ██║███████║██║  ██║██║██║        ██║
╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝╚═╝        ╚═╝
```

**怠竜 Tearyū · Universal File Converter**

![Version](https://img.shields.io/badge/version-1.0.0-00fff7?style=flat-square)
![Python](https://img.shields.io/badge/python-3.8+-00fff7?style=flat-square&logo=python&logoColor=white)
![License](https://img.shields.io/badge/license-MIT-ff153f?style=flat-square)
![Dependencies](https://img.shields.io/badge/dependencies-zero-00fff7?style=flat-square)
![Formats](https://img.shields.io/badge/formats-CSV_%C2%B7_JSON_%C2%B7_XML-3a486a?style=flat-square)
![Skill](https://img.shields.io/badge/Claude_Code-skill-712637?style=flat-square)
![Paths](https://img.shields.io/badge/conversion_paths-6-ff153f?style=flat-square)

</div>

---

*Three formats walk into a bar. None of them can talk to each other. DataShift is the bartender.*

---

It's a file converter. But neon. But with zero install.

**tearyu-datashift** converts between CSV, JSON, and XML across all 6 directions — with one command, no pip installs, and no frameworks. It's a Claude Code skill that bundles a standalone Python script using nothing but the standard library.

Auto-detects your input format. Handles nested structures. Preserves UTF-8. Validates before converting. Returns errors that actually tell you what went wrong.

---

## Conversion Paths

| From → To | Command |
|-----------|---------|
| **CSV → JSON** | `python datashift.py data.csv -t json` |
| **CSV → XML**  | `python datashift.py data.csv -t xml` |
| **JSON → CSV** | `python datashift.py data.json -t csv` |
| **JSON → XML** | `python datashift.py data.json -t xml` |
| **XML → JSON** | `python datashift.py data.xml -t json` |
| **XML → CSV**  | `python datashift.py data.xml -t csv` |

---

## Install as Claude Code Skill

```bash
# Clone into your Claude skills directory
git clone https://github.com/The-Lazy-Dragon/tearyu-datashift \
  ~/.claude/skills/tearyu-datashift
```

Once installed, just ask Claude Code to convert your file. It picks up the skill automatically.

> "Convert employees.csv to XML with a `<person>` element per row"
> "Turn this nested JSON into a flat CSV"
> "Convert data.xml to JSON and preserve all attributes"

---

## Use as a Standalone CLI Tool

No installation beyond Python 3.8+ required. Copy `datashift.py` anywhere and run:

```bash
python datashift.py <input> -t <format> [options]
```

### Options

| Flag | Default | Description |
|------|---------|-------------|
| `-f`, `--from` | auto | Force source format (`csv` / `json` / `xml`) |
| `-t`, `--to` | *(required)* | Target format |
| `-o`, `--output` | auto | Output file path |
| `--root TAG` | `root` | XML root element name |
| `--record TAG` | `record` | XML element name per row/item |
| `--indent N` | `2` | Indentation spaces in JSON/XML output |
| `--no-inference` | off | Keep CSV cells as plain strings |
| `--flatten-sep SEP` | `.` | Separator for flattened nested keys (`_` for underscore) |
| `-v`, `--verbose` | off | Print detailed stats after conversion |

---

## Examples

### CSV → JSON (with type inference)

```bash
python datashift.py employees.csv -t json -v
```
```
[OK] CSV → JSON  'employees.csv' → 'employees.json'
     rows: 3
     fields: ['id', 'name', 'department', 'active']
```

`"42"` becomes `42`, `"true"` becomes `true`, `""` becomes `null`. Pass `--no-inference` to keep everything as strings.

---

### CSV → XML (custom element names)

```bash
python datashift.py employees.csv -t xml --root employees --record employee
```

```xml
<?xml version="1.0" encoding="UTF-8"?>
<employees>
  <employee>
    <id>1</id>
    <name>Alice Chen</name>
    <department>Engineering</department>
    <active>true</active>
  </employee>
</employees>
```

---

### JSON → CSV (nested object flattening)

```json
{ "user": { "name": "Alice", "address": { "city": "Taipei" } }, "score": 99 }
```

```bash
python datashift.py data.json -t csv --flatten-sep _
```

```csv
user_name,user_address_city,score
Alice,Taipei,99
```

---

### XML → JSON (attributes → `@` keys)

```xml
<person id="1" type="admin">
  <name>Alice</name>
</person>
```

```json
[
  {
    "@id": "1",
    "@type": "admin",
    "name": "Alice"
  }
]
```

Pass the resulting JSON back through `json_to_xml` and the `@` keys become attributes again — fully round-trippable.

---

### XML → CSV (nested + attributes flattened)

```xml
<people>
  <person id="1">
    <name>Alice</name>
    <address><city>Taipei</city></address>
  </person>
</people>
```

```csv
@id,name,address.city
1,Alice,Taipei
```

---

## What Gets Preserved

| Source structure | Output behavior |
|-----------------|----------------|
| CSV headers | JSON keys / XML element names (space → underscore) |
| CSV values | Type-inferred as int / float / bool / null (disable with `--no-inference`) |
| JSON nested objects | Flattened to `parent.child` keys in CSV |
| JSON arrays (root) | One row per item in CSV / one `<record>` per item in XML |
| JSON arrays (nested) | Repeated XML elements of the same tag / indexed CSV keys |
| JSON `@attr` keys | XML attributes |
| XML attributes | `@attr` keys in JSON, `@attr` columns in CSV |
| XML same-tag siblings | JSON arrays (auto-detected) |
| UTF-8 content | Preserved throughout (`ensure_ascii=False`) |

---

## Error Messages

DataShift validates before converting and returns errors that tell you what to fix:

```
[ERROR] 'data.json' is not valid JSON.
  → Expecting ',' delimiter: line 4, column 3.

[ERROR] 'legacy.csv' contains non-UTF-8 characters.
        Re-save the file as UTF-8 and try again.

[ERROR] XML root element has no children.
        DataShift maps each child element to one CSV row —
        there must be at least one.

[WARN]  Row(s) [3, 7] have a different column count than the header (5 cols).
        Missing cells will be empty, extra cells will be ignored.
```

Warnings are non-fatal — the conversion completes. Errors stop execution with exit code 1.

---

## Project Structure

```
tearyu-datashift/
├── SKILL.md          Claude Code skill — install to ~/.claude/skills/
├── datashift.py      Standalone converter — no dependencies
├── CHANGELOG.md      Version history
├── WARP.md           Quick reference card
├── requirements.txt  Documented stdlib modules (no pip installs)
└── examples/
    ├── README.md     Walkthrough of all 6 conversion paths
    ├── sample.csv    Flat tabular data (3 records, 6 fields)
    ├── sample.json   Flat JSON array (same data as sample.csv)
    ├── sample.xml    XML with child elements (same data)
    ├── nested.json   Nested JSON with arrays (for flattening examples)
    └── nested.xml    XML with attributes and nested elements
```

---

## Requirements

- Python 3.8 or higher
- No external packages

Modules used: `csv`, `json`, `xml.etree.ElementTree`, `xml.dom.minidom`, `argparse`, `pathlib`, `re`, `sys` — all in stdlib since Python 3.2.

---

## Also check out

| Project | What it is |
|---------|-----------|
| [**NavalStrike**](https://github.com/The-Lazy-Dragon/NavalStrike) | Battleship · 25 ships · 35 achievements · procedural audio · hard AI · one `.html` |
| [**lazy-dragons-tictactoe**](https://github.com/The-Lazy-Dragon/lazy-dragons-tictactoe) | TicTacToe · Minimax AI · achievements · dev console · one `.html` |
| [**Tearyu-Deadshot-Crosshair**](https://github.com/The-Lazy-Dragon/Tearyu-Deadshot-Crosshair) | Chrome extension + Android branch alpha · crosshair for deadshot.io |
| [**tearyu-humanizer**](https://github.com/The-Lazy-Dragon/tearyu-humanizer) | Claude Code skill · strips AI texture from writing · v1.1 |

---

<div align="center">

Built with zero frameworks and questionable life choices — actually zero external dependencies, just Python's stdlib. Installing a 40MB package to read a comma-separated file is a symptom, not a solution.

**怠竜 · TEARYŪ — The Lazy Dragon**

</div>
