# Changelog — tearyu-datashift

All notable changes to this project will be documented here.
Format: [Semantic Versioning](https://semver.org)

---

## [1.0.0] — 2026-06-02

### Initial Release

**6 conversion paths — all directions supported:**

- **CSV → JSON** — DictReader-based, type inference on by default (int/float/bool/null),
  disable with `--no-inference`. Outputs a JSON array of objects.
- **CSV → XML** — Each row becomes a `<record>` element under `<root>`.
  Element names configurable via `--root` and `--record`. Sanitizes CSV headers
  to valid XML tag names automatically.
- **JSON → CSV** — Handles root arrays, root objects with array fields, and single
  objects. Nested structures flattened to dot-notation keys (e.g. `address.city`).
  Separator configurable via `--flatten-sep`.
- **JSON → XML** — Root arrays → repeated `<record>` elements. Root objects →
  recursive element nesting. Dict keys with `@` prefix → XML attributes.
  `#text` keys → element text content.
- **XML → JSON** — Uniform children (same tag) → JSON array. Mixed children →
  nested dict. Repeated same-tag siblings auto-collected into arrays. Attributes
  preserved as `@attr` keys.
- **XML → CSV** — Each direct child of root → one CSV row. Nested elements and
  attributes flattened with dot-notation (or custom separator). `@attr` columns
  preserved.

**Format detection:**
- Extension-first: `.csv`, `.json`, `.xml`, `.rss`, `.atom`, `.svg`, `.jsonl`
- Content sniffing fallback: `{`/`[` → JSON, `<` → XML, column-count heuristic → CSV
- `--from` flag to override

**Validation with descriptive errors:**
- CSV: empty file, header-only, mismatched column counts (warning, not error)
- JSON: syntax errors with line/column number
- XML: parse errors with position
- UTF-8 encoding issues with re-save instructions
- Missing files, permission errors, unwritable output paths

**CLI:**
- `--root`, `--record` for XML element naming
- `--indent` for JSON/XML pretty-printing (default: 2 spaces)
- `--no-inference` to keep CSV cells as plain strings
- `--flatten-sep` separator for flattened nested keys (default: `.`)
- `-v` / `--verbose` for detailed stats
- `--version` flag
- Exit code 0 on success, 1 on error

**Data preservation:**
- UTF-8 throughout (`ensure_ascii=False` in JSON output)
- Round-trippable: JSON `@attr` keys ↔ XML attributes
- Repeated XML same-tag children ↔ JSON arrays
- Nested JSON objects ↔ flattened CSV with dot-notation headers

**Claude Code skill:**
- `SKILL.md` with full step-by-step workflow
- Inline fallback instructions when script is unavailable
- Error handling table and data preservation matrix
- Examples directory with sample files for all 6 paths

---

## Roadmap

**v1.1** (planned)
- TSV (tab-separated values) support
- JSONL (JSON Lines) input/output
- `--delimiter` flag for custom CSV separators
- `--encoding` flag for non-UTF-8 source files
- `--array-sep` flag for joining list values in CSV (default: ` | `)
- Streaming mode for large files (chunked reading)

**v1.2** (planned)
- YAML support (CSV/JSON/XML ↔ YAML)
- `--schema` flag for output validation against JSON Schema
- Batch conversion: `datashift *.csv -t json`
- `--merge` flag: combine multiple input files into one output

---

怠竜 · TEARYŪ — The Lazy Dragon
